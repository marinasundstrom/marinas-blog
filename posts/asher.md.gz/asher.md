### She

Asher (אֲשֶׁר) har också givit upphov till partikeln som markerar relativsats:

`asher -> she-` (som, att, vilket)

#### Exempel 1 – “som” (relativsats)

הילדה שֶׁאוֹהֶבֶת לִקְרוֹא בָּאָה.

Ha-yalda she-ohevet likro ba'ah.

Flickan som gillar att läsa kom.

#### Exempel 2 – "att" (subjunktion)

הוּא אָמַר שֶׁהוּא עָיֵף.

Hu amar she-hu ayef.

Han sa att han är trött.

#### Exempel 3 – "vilket" (efter en hel sats)

היא נִצְחָה בַּמִּשְׂחָק, שֶׁמָּשֶׁהוּ מַפְתִּיעַ.

Hi nitzcha ba-mis'chak, she-mashehu maftia.

Hon vann matchen, vilket är överraskande.
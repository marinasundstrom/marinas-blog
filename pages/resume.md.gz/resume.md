## Summary

Software engineer with more than 10 years of professional experience working on software solutions. Have worked across the software stacks, helping companies develop applications and larger systems, both as a full-time employee and as a consultant. Consider myself goal-oriented and product-focused. Skilled at software patterns and practices.